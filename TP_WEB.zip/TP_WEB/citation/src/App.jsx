import React, { useState } from "react";
import QuoteBox from "./components/QuoteBox";



const quotes = [
  { text: "La vie est un mystère qu’il faut vivre, et non un problème à résoudre.", author: "Gandhi" },
  { text: "Le succès c’est tomber sept fois, se relever huit.", author: "Proverbe japonais" },
  { text: "Il n’y a pas de raccourci vers n’importe où qui en vaille la peine.", author: "Beverly Sills" },
  { text: "Rien ne vaut une bonne citation motivante pour démarrer la journée.", author: "Anonyme" },
  { text:  "La vie appartient à ceux qui se lèvent tot. " ,author: "Anonyme"},
];

function App() {
  const [currentQuote, setCurrentQuote] = useState(quotes[0]);

  const generateNewQuote = () => {
    const randomIndex = Math.floor(Math.random() * quotes.length);
    setCurrentQuote(quotes[randomIndex]);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-100 to-indigo-200 grid place-items-center p-4 ">
     <div className="frame-style">
    <QuoteBox quote={currentQuote} onNewQuote={generateNewQuote} />
    
  </div>
</div>
  );
}

export default App;
