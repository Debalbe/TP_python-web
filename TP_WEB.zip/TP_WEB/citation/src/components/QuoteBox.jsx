import React from "react";

const QuoteBox = ({ quote, onNewQuote }) => {
  return (
    <div className="bg-white p-6 rounded-2xl shadow-lg text-center w-full max-w-xl transition-opacity duration-300">
      <p className="text-xl italic text-gray-700 mb-4">"{quote.text}"</p>
      <p className="text-right font-semibold text-gray-600 mb-6">— {quote.author}</p>
      <button
        onClick={onNewQuote}
        className="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-xl transition duration-300"
      >
        Nouvelle citation
      </button>
    </div>
  );
};

export default QuoteBox;
